## 部分可持久化

所有版本都可以访问，但是只有最新版本可以修改。

## 完全可持久化

所有版本都既可以访问又可以修改。

## 参考

 <https://en.wikipedia.org/wiki/Persistent_data_structure> 

author: ChungZH, partychicken, Xeonacid

## Atom - GitHub 家的编辑器

### 简介

Atom 是一个免费、开源、跨平台的由 GitHub 开发的程序编辑器。它是用 JavaScript 编写的，并且采用 Electron 架构。官网是 <https://atom.io/> 。它的一个较大缺点就是性能差。

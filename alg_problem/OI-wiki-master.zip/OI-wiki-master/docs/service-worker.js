this.addEventListener('fetch', function (event) {
  //
});
